CustomTVs.panel.PanelLatLng = function(config) {
	config = config || {};
	
	var clone = this;
	
	Ext.apply(config, Ext.decode(config.tvConfig));

	Ext.apply(config, {
        layout		: 'form',
        labelAlign		: 'top',
        labelSeparator	: '',		
		items		: [{
	        xtype			: 'textfield',
	        fieldLabel		: _('customtvs.latlng_label_lat'),
	        id				: 'customtvs-latlng-' + config.tvId + '-lat',
			name			: 'lat',
	        width			: '99%',
	        allowBlank		: true
	    }, {
			xtype			: 'textfield',
			fieldLabel		: _('customtvs.latlng_label_lng'),
			id				: 'customtvs-latlng-' + config.tvId + '-lng',
			name			: 'lng',
			width			: '99%',
			allowBlank		: true
		}, {
			xtype			: 'google-maps',
			cls				: 'x-form-googlemaps',
			id				: 'customtvs-latlng-' + config.tvId + '-google-maps',
			width			: '99%',
			height			: '250px',
			hidden			: 0 == parseInt(config.google_maps) ? true : false,
			gmapListeners	: {
				'click'			: function(event) {
					this.location = clone.encodeData(event.latLng, clone);
					
					this.setMarker(new google.maps.LatLng(this.location.lat, this.location.lng));
				}
			},
			listeners		: {
				'beforeRender'	: function(event) {
					this.location = Ext.decode(Ext.get('tv' + clone.tvId).dom.value);
		
					Ext.getCmp('customtvs-latlng-' + clone.tvId + '-lat').setValue(this.location.lat);
					Ext.getCmp('customtvs-latlng-' + clone.tvId + '-lng').setValue(this.location.lng);
				}
			}
		}, {
		    xtype			: MODx.expandHelp ? 'label' : 'hidden',
		    hidden			: 0 == parseInt(config.google_maps) ? true : false,
		    html			: _('customtvs.latlng_google_maps_desc'),
		    cls				: 'desc-under'
		}]

	});
	
	var inputFields = config.input_fields.split(',');
	
	for (var input in inputFields) {
		if ('string' == typeof inputFields[input]) {
			Ext.get('tv' + inputFields[input]).on({
				'change'	: {
					fn			: this.geoCodeLookup,
					scope		: this
				}
			});
		}
	}
	
	CustomTVs.panel.PanelLatLng.superclass.constructor.call(this, config);
};
	
Ext.extend(CustomTVs.panel.PanelLatLng, Ext.Panel, {
	geoCodeLookup: function() {
		var address		= '';
		var inputFields = this.input_fields.split(',');
		
		for (var input in inputFields) {
			if ('string' == typeof inputFields[input]) {
				if ('' != (value = Ext.get('tv' + inputFields[input]).getValue())) {
					address += value + ' ';
				}
			}
		}
		
		Ext.getCmp('customtvs-latlng-' + this.tvId + '-google-maps').geoCodeLookup(address.trim(), this.encodeData, this);
	},
	encodeData: function(event, clone) {
		var data = {
			lat		: event.lat(),
			lng		: event.lng()
		}
		
		Ext.get('tv' + clone.tvId).dom.value = Ext.encode(data);
		
		Ext.getCmp('customtvs-latlng-' + clone.tvId + '-lat').setValue(data.lat);
		Ext.getCmp('customtvs-latlng-' + clone.tvId + '-lng').setValue(data.lng);
		
		return data;
	}
});
	
Ext.reg('customtvs-latlng-panel-tv', CustomTVs.panel.PanelLatLng);