----------------------
Custom TVs
----------------------
Version: 1.0.2
Author: Oene Tjeerd de Bruin
Contact: info@oetzie.nl
----------------------

Custom TVs gives your extra template variables.

Possible uses include:
- Grid template variable (like MIGX)
- Google maps template variable
